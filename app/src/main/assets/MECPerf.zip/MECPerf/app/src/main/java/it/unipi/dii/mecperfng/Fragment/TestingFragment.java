package it.unipi.dii.mecperfng.Fragment;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.airbnb.lottie.LottieAnimationView;

import java.util.LinkedHashMap;
import java.util.Map;

import it.unipi.dii.mecperfng.MainUtils;
import it.unipi.dii.mecperfng.R;

public class TestingFragment extends Fragment {

    //bottone per dare inizio al test della performance
    Button startTestButton;
    ImageView swipeUp;

    //grafica swipe out
    int colors[] = { Color.parseColor("#0C2431"), Color.parseColor("#512DA8") };
    GradientDrawable gradientDrawable;
    RelativeLayout backgroundHome;

    float posizioneYiniziale;
    ImageView zonaDiArrivoSwipeOut;
    //stampa a video tutti gli avvisi di interesse dell'utente circa i calcoli rtt e bandwith che si stanno svolgendo
    TextView logUtente;
    Button TCPButton;
    //booleano per capire se il bottone è premuto o meno
    boolean bottone_premuto;
    //riferimento al contenitore dell'animazione
    LottieAnimationView animazioneTesting;
    LottieAnimationView animazioneSparkle;

    private SharedPreferences preferences;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.testing_layout, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        animazioneSparkle = (LottieAnimationView)getActivity().findViewById(R.id.animazione_sparkle);
        animazioneSparkle.playAnimation();
        //----------------------------------------------BOTTONE TESTING ----------------------------------------------
        startTestButton = getActivity().findViewById(R.id.buttonStartTest);
        logUtente = getActivity().findViewById(R.id.logUtente);
        bottone_premuto = false;
        startTestButton.setOnClickListener(new View.OnClickListener() {
            //con questa funzione gestisco il testing
            @Override
            public void onClick(View v) {
                Log.d("MyLOG","animation start");
                animazioneTesting = (LottieAnimationView)getActivity().findViewById(R.id.animazione_testing);

                if(!bottone_premuto){
                    //-----------------dettagli di stile/animazione --------------------------------
                    startTestButton.setBackgroundResource(R.drawable.start_testbutton_pressed_style);
                    startTestButton.setTextColor(Color.parseColor("#3C00DDFF"));
                    animazioneTesting.playAnimation();
                    //avvio calcolo rtt e bandwidth sia come sender, sia come receiver
                    avviaMisurazione();
                    bottone_premuto = true;
                }
            }
        });


        backgroundHome = getActivity().findViewById(R.id.relativeLayoutHome);




        preferences = PreferenceManager.getDefaultSharedPreferences(getActivity().getBaseContext());

        Spinner spinner = getActivity().findViewById(R.id.spinner);
        //ottengo la lista dalla risorsa values/array.xml per popolare lo spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity().getApplicationContext(),
                R.array.function_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        //verifyStoragePermissions(this);
/*
        TCPButton = getActivity().findViewById(R.id.buttonStartTest);

        TCPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO: SALVA LA KEYWORD

  //              final EditText editText = getActivity().findViewById(R.id.keyWordEditView);
//                String keyword = editText.getText().toString();
    //            if(keyword.equals("")){
      //              keyword="DEFAULT";
        //        }
                Log.d("TASK","START TCP BAND");
                mAsyncTask = new TestingFragment.AsyncCMD("TCPBANDWIDTHBUTTON", "TEST"); //TODO: METTERE AL POSTO DI 'TEST' LA KEYWORD
                mAsyncTask.execute((Void) null);
                Log.d("TASK", "Task Eseguito");
            }
        });
*/
        Button UDPButton = getActivity().findViewById(R.id.buttonStartTest);
        UDPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO: SALVA LA KEYWORD

               // final EditText editText = getActivity().findViewById(R.id.keyWordEditView);
                //String keyword = editText.getText().toString();
                //if(keyword.equals("")){
                  //  keyword="DEFAULT";
                //}


                mAsyncTask = new TestingFragment.AsyncCMD("UDPBANDWIDTHBUTTON", "TEST");  //TODO: METTERE AL POSTO DI 'TEST' LA KEYWORD
                mAsyncTask.execute((Void) null);
                Log.d("TASK", "Task Eseguito");
            }
        });
/*
        Button TCPRTTButton = getActivity().findViewById(R.id.buttonStartTest);
        TCPRTTButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO: SALVA LA KEYWORD

                //final EditText editText = getActivity().findViewById(R.id.keyWordEditView);
               // String keyword = editText.getText().toString();
                //if(keyword.equals("")){
                  //  keyword="DEFAULT";
                //}

                 mAsyncTask = new TestingFragment.AsyncCMD("TCPRTTBUTTON","TEST"); //TODO: METTERE AL POSTO DI 'TEST' LA KEYWORD
                 mAsyncTask.execute((Void) null);
            }
        });

        Button UDPRTTButton = getActivity().findViewById(R.id.buttonStartTest);
        UDPRTTButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO: SALVA LA KEYWORD

              //  final EditText editText = getActivity().findViewById(R.id.keyWordEditView);

               // String keyword = editText.getText().toString();
                //if(keyword.equals("")){
                  //  keyword="DEFAULT";
                //}

                 mAsyncTask = new TestingFragment.AsyncCMD("UDPRTTBUTTON", "TEST");//TODO: METTERE AL POSTO DI 'TEST' LA KEYWORD
                 mAsyncTask.execute((Void) null);
            }
        });
*/
    }



    /* Avvia il calcolo dell'RTT e della bandwidth sia come sender che come receiver.
       Alla fine tutti i risultati sono salvati nell'Aggregator.
     */
    private void avviaMisurazione(){

        //CALCOLO RTT_______________________________________________________________________________

            //TCP-RTT---------------------------------------------------------
                //avviso l'utente dell'inizio dell'operazione...
                logUtente.setText("RTT ");
    }


    //--------------------CLASSE PRIVATA PER LA GESTIONE DEL CALCOLO DEI PARAMETRI TRAMITE ASYNC TASK----------------------------
    private static final int REQUEST_INTERNET = 1;
    private static String[] PERMISSIONS_INTERNET = {
            Manifest.permission.INTERNET
    };
    private static final int CMDPORT = 6792;//6789
    private static final int TCPPORT = 6791;//6788
    private static final int UDPPORT = 6790;//6787
    private static final int AGGRPORT = 6766;
    private static final int NUMTEST_UDP_CAPACITY = 25; //TODO remove
    private TestingFragment.AsyncCMD mAsyncTask = null;



    private class AsyncCMD extends AsyncTask<Void, Void, Integer> {
        private String cmd;
        private String keyword;



        public AsyncCMD(String cmd, String keyw) {
            super();
            this.cmd = cmd;
            this.keyword = keyw;
        }



        @Override
        protected Integer doInBackground(Void... voids) {

            //OTTIENI L'IP DELL'OBSERVER
            String observerAddress = preferences.getString("observer_address", "NESSUN INDIRIZZO");
            Log.d("MyLOG","observer_address:"+observerAddress);
            //OTTIENI L'IP DELL'AGGREGATOR TODO: NON E' USATO PERCHE' DEVI IMPLEMENTARE TU LA FUNZIONALITA' DI PRELIEVO DAL DBMS
            String aggregatorAddress = preferences.getString("aggregator_address", "NESSUN INDIRIZZO");
            Log.d("MyLOG","aggregator_address:"+aggregatorAddress);

            //OTTIENI IL NUMERO DI TEST CONSECUTIVI DA SVOLGERE
            int numberOfConsecutiveTests = Integer.parseInt(preferences.getString(
                    "number_of_consecutive_tests", "1"));

            //PRELEVA LA DIREZIONE DI MISURA: SI VUOLE INVIARE O RICEVERE
            Spinner direction_spinner = getActivity().findViewById(R.id.spinner);
            String direction = direction_spinner.getItemAtPosition(direction_spinner
                    .getSelectedItemPosition()).toString();

            int outcome;
            //CMD CONTIENE UNO DEI 4 BOTTONI SELEZIONATI, E QUINDI DISCRIMINA TRA LARGHEZZA DI BANDA E LATENZA
            switch (cmd) {
                case "TCPBANDWIDTHBUTTON":{
                    //OTTENGO GLI L BIT DI OGNI PACCO
                    int tcp_bandwidth_pktsize = Integer.parseInt(preferences.getString(
                            "pack_size_TCP_BANDWIDTH", "1024")),
                            //OTTENGO IL NUMERO DI PACCHETTI DA INVIARE
                            tcp_bandwidth_num_pkt = Integer.parseInt(preferences.getString(
                                    "num_pack_TCP_BANDWIDTH", "1024"));

                    //PER IL NUMERO DI TEST DA EFFETTUARE...
                    for (int i = 0; i< numberOfConsecutiveTests;i++) {
                        //OTTENGO LA LARGHEZZA DI BANDA NELLA CONNESSIONE TRA ME E L'OBSERVER NELL'INVIO DI UN CERTO NUMERO DI PACCHETTI DI L BIT
                        outcome = MainUtils.tcpBandwidthMeasure(direction, keyword, CMDPORT,
                                observerAddress, TCPPORT,
                                tcp_bandwidth_pktsize, tcp_bandwidth_num_pkt, null);
                        String txt = "TCP bandwidth " + i + ": ";
                        if (outcome != 0) {
                            txt += "FAILED";
                            i--;
                        }
                        else
                            txt += "SUCCESS";

                        Log.d("Measures", txt);
                    }

                    return 0;
                }
                case "UDPBANDWIDTHBUTTON": {
                    int udp_bandwidth_pktsize = Integer.parseInt(preferences.getString(
                            "pack_size_UDP_BANDWIDTH", "1024"));

                    for (int i = 0; i < numberOfConsecutiveTests; i++) {

                        outcome = MainUtils.udpBandwidthMeasure(direction, keyword, CMDPORT,
                                observerAddress, UDPPORT,
                                udp_bandwidth_pktsize, null, NUMTEST_UDP_CAPACITY);
                        String txt = "UDP bandwidth " + i + ": ";
                        if (outcome != 0){
                            txt += "FAILED";
                            i--;
                        }
                        else
                            txt += "SUCCESS";
                        Log.d("Measures", txt);
                    }

                    return 0;
                }
                case "TCPRTTBUTTON": {
                    int tcp_rtt_pktsize = Integer.parseInt(preferences.getString(
                            "pack_size_TCP_RTT", "1"));
                    int tcp_rtt_num_pack = Integer.parseInt(preferences.getString(
                            "num_pack_TCP_RTT", "100"));

                    for (int i = 0; i < numberOfConsecutiveTests; i++) {

                        /*SE outcome NON FALLISCE ALLORA LA MAP PASSATA COME ARGOMENTO FORMALE E' CONSISTENTE E
                          CONTIENE PER OGNI PACCHETTO IL RELATIVO RTT  (NB: TUTTO QUESTO PER OGNI TEST EFFETTUATO!)
                         */
                        Map<Integer, Long[]> mappa = new LinkedHashMap<>();

                        outcome = MainUtils.tcpRTTMeasure(direction, keyword, CMDPORT,
                                observerAddress, TCPPORT,
                                tcp_rtt_pktsize, tcp_rtt_num_pack, null, mappa);
                        String txt = "TCP RTT " + i + ": ";
                        if (outcome != 0){
                            txt += "FAILED";
                            i--;
                        }
                        else {
                            txt += "SUCCESS";
                            for (Integer key : mappa.keySet()) {
                                System.out.println(key + " --TCPRTT-- " + mappa.get(key)[0]);
                            }
                        }
                        Log.d("Measures", txt);
                    }
                    return 0;
                }
                case "UDPRTTBUTTON": {
                    int udp_rtt_pktsize = Integer.parseInt(preferences.getString(
                            "pack_size_UDP_RTT", "1"));
                    int udp_rtt_num_pack = Integer.parseInt(preferences.getString(
                            "num_pack_UDP_RTT", "100"));

                    for (int i = 0; i < numberOfConsecutiveTests; i++) {

                        /*SE outcome NON FALLISCE ALLORA LA MAP PASSATA COME ARGOMENTO FORMALE E' CONSISTENTE E
                          CONTIENE PER OGNI PACCHETTO IL RELATIVO RTT
                         */
                        Map<Integer, Long[]> mappa = new LinkedHashMap<>();
                        outcome = MainUtils.udpRTTMeasure(direction, keyword, CMDPORT,
                                observerAddress, UDPPORT,
                                udp_rtt_pktsize, udp_rtt_num_pack, null, mappa);
                        String txt = "UDP RTT " + i + ": ";
                        if (outcome != 0){
                            txt += "FAILED";
                            i--;
                        }
                        else {
                            txt += "SUCCESS";
                            for(Integer key : mappa.keySet()) {
                                System.out.println(key+" ---- "+mappa.get(key)[0]);
                            }
                        }
                        Log.d("Measures", txt);
                    }
                    return 0;
                }
            }
            return 0;
        }


        @Override
        protected void onPostExecute(Integer resultValue) {
            if(resultValue == 0) {
                CharSequence txt = "Successful Measurement! Available in Results section";
                int duration = Toast.LENGTH_SHORT;
                Context ctx = getActivity().getApplicationContext();
                Toast toast = Toast.makeText(ctx, txt, duration);
                toast.show();

            } else {
                Context ctx = getActivity().getApplicationContext();
                CharSequence txt = "Error in Measurement!Try later...";
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(ctx, txt, duration);
                toast.show();
            }

        }


        @Override
        protected void onCancelled() {
            mAsyncTask = null;
        }
    }


    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.INTERNET);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(activity, PERMISSIONS_INTERNET, REQUEST_INTERNET);

        }
    }




}
