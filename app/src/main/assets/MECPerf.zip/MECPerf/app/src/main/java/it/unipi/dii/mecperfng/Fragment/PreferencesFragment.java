package it.unipi.dii.mecperfng.Fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import it.unipi.dii.mecperfng.R;


public class PreferencesFragment extends PreferenceFragmentCompat {

    private ListPreference listaPreferenze;

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        FrameLayout fl = getActivity().findViewById(R.id.fragment_container);
        fl.setBackground(getResources().getDrawable(R.drawable.rounded_menubar));
        setPreferencesFromResource(R.xml.root_preferences, rootKey);
    }
/*
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.preferences_layout, container, false);




        return view;
    }
*/
}

