package com.coders.testforcnr;

import androidx.appcompat.app.AppCompatActivity;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText indirizzoIP,
             messaggioDaInviare;
    Button bottoneSend,
           bottoneServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        indirizzoIP = findViewById(R.id.IpDispositivo);
        messaggioDaInviare = findViewById(R.id.Messaggio);
        bottoneSend = findViewById(R.id.BottoneInvia);
        bottoneServer = findViewById(R.id.bottoneServer);

    }

    public void avviaServer(View v){

    //AVVIO IL SERVER
        Thread server = new Thread(new MyServerSocket());
        server.start();
        Toast.makeText(getApplicationContext(),"server avviato",Toast.LENGTH_SHORT).show();
    }


    public void sendMessage(View v){
        BackgroundTask b = new BackgroundTask();
        b.execute(indirizzoIP.getText().toString(),messaggioDaInviare.getText().toString());
        Toast.makeText(getApplicationContext(),"inviato all'indirizzo "+indirizzoIP.getText().toString()+" il messaggio "+messaggioDaInviare.getText().toString(),Toast.LENGTH_SHORT).show();
    }

    //SERVER SOCKET (CHI RICEVE)--------------------------------------------
    class MyServerSocket implements Runnable {

        ServerSocket ss;
        Socket s;
        DataInputStream dis;
        String messaggio;
        //per comunicare col main thread
        Handler handler = new Handler();

        @Override
        public void run() {

            try {
                //CREO IL SERVER ALLA PORTA 9700
                Log.d("MyMEX","server: waiting....");
                ss = new ServerSocket(9700);
                while(true){
                    //MI METTO IN ATTESA CHE QUALCUNO MI CONTATTI
                    s = ss.accept();
                    //QUALCUNO MI HA CONTATTATO (RICORDA CHE accept() E' BLOCCANTE)
                    //IL SOCKET HA RICEVUTO UN CANALE CHE TRASFORMO IN INPUT
                    Log.d("MyMEX","server: qualcuno si è connesso");
                    dis = new DataInputStream(s.getInputStream());
                    //SALVO IL MESSAGGIO RICEVUTO DAL CANALE
                    messaggio = dis.readUTF();
                    //ENTRO NEL MAIN-THREAD PER SCRIVERE SU UI
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),"messaggio ricevuto:"+messaggio,Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }catch(IOException e){
                e.printStackTrace();
            }
        }
    }



    //CLIENT SOCKET (CHI INVIA)----------------------------------------------
    class BackgroundTask extends AsyncTask<String,Void,String>
    {
        Socket s;
        DataOutputStream dos;
        String ip,messaggio;

        @Override
        protected String doInBackground(String... params) {

            ip = params[0];
            messaggio = params[1];
            try {
                Log.d("MyMEX","client: voglio mandare all'indirizzo"+ip+"il messaggio "+messaggio+" host:"+ InetAddress.getByName("vivek-PC").getHostAddress());
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
            try {
                //creo un socket
                Log.d("MyMEX","client: connessione a "+ip);
                s = new Socket(ip,9700);
                Log.d("MyMEX","client: connessione a "+ip+" effettuata con successo.");
                //se la connessione è evvenuta, s ha un canale (stream)
                //siccome voglio inviare, trasformo tale canale in outputstream
                dos = new DataOutputStream(s.getOutputStream());
                //ci scrivo dentro il messaggio
                dos.writeUTF(messaggio);

                //CHIUDO IL CANALE E IL SOCKET
                dos.close();
                s.close();
            }catch(IOException e){
                e.printStackTrace();
            }

            return null;
        }
    }
}
