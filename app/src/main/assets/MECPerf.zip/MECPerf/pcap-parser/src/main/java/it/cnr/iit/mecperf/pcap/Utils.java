package it.cnr.iit.mecperf.pcap;

public class Utils {
    public static final int SEND_TYPE_BW = 0;
    public static final int SEND_TYPE_RTT = 1;
    public static final int SEND_TYPE_END = 2;
    public static final String PARSE_END = "END";
}
