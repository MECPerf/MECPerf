#!/bin/bash
java -cp /usr/share/java/mysql.jar:/home/ubuntu/Aggregator.jar it.unipi.dii.aggregator.Aggregator --database-ip "" --database-name "" --database-user "" --database-password "" --aggregator-port 6766
